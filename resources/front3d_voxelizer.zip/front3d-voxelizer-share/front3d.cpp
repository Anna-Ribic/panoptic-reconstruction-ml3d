#include "front3d.h"
#include <fstream>
#include <iostream>
#include <filesystem>
#include "nlohmann/json.hpp"

using njson = nlohmann::json;

namespace fs = std::filesystem;

using namespace Front3D;

vec3f std_to_vec3(const std::vector<float>& vector) 
{
	vec3f vec(vector[0], vector[1], vector[2]);
	return vec;
}

quatf std_to_quat(const std::vector<float>& vector)
{
	quatf quat(vector[3], vector[0], vector[1], vector[2]);
	return quat;
}



void Scene::load_from_json(const std::string& filepath, const std::string& shape_path, const std::string& scene_image_path,
	const std::string& category_mapping_path)
{
	// parse category
	category_mapping.init(category_mapping_path, "name", "id");
	
	// parse json
	std::ifstream input_file(filepath);
	njson content;
	input_file >> content;
	
	// parse scene information
	id = content["uid"];
	const auto& scene_node = content["scene"];
	translation = std_to_vec3(scene_node["pos"]);
	rotation = std_to_quat(scene_node["rot"]);
	scale = std_to_vec3(scene_node["scale"]);

	// parse furniture
	parse_and_load_furniture(content["furniture"], shape_path);

	// parse meshes from file
	parse_meshes(content["mesh"]);

	// parse room information and create objects

	// load room mapping file
	const auto room_mapping = load_room_mapping(scene_image_path + id + "/room_mapping.json");
	
	for (const auto& room : scene_node["room"])
	{
		const std::string room_name = room["instanceid"];
		const std::string room_path = scene_image_path + "/" + id + "/" + room_name;
		
		// find room number
		const auto& room_number_it = room_mapping.find(room_name);

		if (fs::exists(room_path) && room_number_it != room_mapping.end())
		{			
			parse_room(room);
			const int room_number = room_number_it->second;
			std::cout << "Assign " << room_number << " to " << room["instanceid"] << std::endl;
			room_index_mapping.emplace(room_number, room["instanceid"]);
		}
		else 
		{
			std::cout << "Skip room: " << room_name << std::endl;
		}
	}

	// load room walls
	for (auto& room_it : rooms) 
	{
		const std::string room_path = scene_image_path + "/" + id + "/" + room_it.first;
		load_room_structures(room_it.second, room_path);
	}

}


void Scene::parse_and_load_furniture(const njson& furniture_node, const std::string& furniture_path)
{
	for (const auto& node: furniture_node)
	{
		Element element;
		element.jid = node["jid"];
		element.uid = node["uid"];

		const auto category_id = node.find("category");
		if (category_id != node.end()) {
			element.category = util::toLower(util::rtrim(*category_id));
		}

		// Check if furniture is in 3D-Future dataset
		const fs::path mesh_file{ furniture_path + "/" + element.jid + "/raw_model.obj" };

		if (fs::exists(mesh_file))
		{
			MeshDataf mesh = MeshIOf::loadFromFile(mesh_file, false);
			element.mesh = mesh;
			furniture.emplace(element.uid, element);
		}
		else 
		{
			std::cout << "Missing in shape dataset: " << mesh_file << std::endl;
		}
	}
}

void Scene::parse_meshes(const njson& meshes_node)
{
	const std::vector<njson>& mesh_modes = meshes_node;
	std::cout << "Found " << mesh_modes.size() << " meshes" << std::endl;
	for (const auto& mesh_node : mesh_modes)
	{
		parse_mesh(mesh_node);
	}
}

void Scene::parse_mesh(const njson& mesh_node)
{
	const std::string mesh_type = mesh_node["type"];
	if (is_excluded_mesh_type(mesh_type) == false)
	{
		Element mesh;
		mesh.jid = mesh_node["jid"];
		mesh.uid = mesh_node["uid"];
		mesh.category = util::toLower(util::rtrim(mesh_type));

		// parse vertices
		const njson& vertices_node = mesh_node["xyz"];

		std::vector<float> vertices_vector;
		vertices_vector.reserve(vertices_node.size());

		// in same cases vertex positions are defined as strings
		if (vertices_node[0].type() == njson::value_t::string) {
			for (const std::string& v : vertices_node)
			{
				float v_float = std::stof(v);
				vertices_vector.push_back(v_float);
			}
		}
		else
		{
			for (const float& v : vertices_node)
			{
				vertices_vector.push_back(v);
			}
		}

		const int num_vertices = static_cast<int>(vertices_vector.size() / 3);
		std::vector<vec3f> vertices;
		vertices.reserve(num_vertices);
		
		for (auto vertex_index = 0u; vertex_index < vertices_vector.size(); vertex_index += 3)
		{
			const vec3f vertex(vertices_vector[vertex_index + 0], vertices_vector[vertex_index + 1], vertices_vector[vertex_index + 2]);
			vertices.push_back(vertex);
		}

		// parse faces
		const std::vector<unsigned int>& faces = mesh_node["faces"];
		
		if (faces.size() > 0)
		{
			mesh.mesh = TriMeshf(vertices, faces);

			unsigned short semantic_label = 0;
			category_mapping.getIdForLabel(mesh.category, semantic_label);

			const int instance_label = instance_counter;
			//std::cout << "ASSIGN LABEL: " << mesh.uid << "\tsem: " << semantic_label << "\tinst: " << instance_label;

			assign_labels_to_mesh(mesh.mesh, semantic_label, instance_label);
			instance_counter++;
			instance_name_instance_id_mapping.emplace(mesh.uid, instance_label);

			//std::cout << "- " << mesh.uid << std::endl;

			structures.emplace(mesh.uid, mesh);
		}
		else
		{
			std::cout << "Mesh does not contain vertex indices." << std::endl;
		}
	}
	
}

bool Scene::is_excluded_mesh_type(const std::string& mesh_type) const
{
	if (std::find(excluded_mesh_types.begin(), excluded_mesh_types.end(), mesh_type) != excluded_mesh_types.end())
	{
		return true;
	}
	else 
	{
		return false;
	}
}

std::map<std::string, int> Scene::load_room_mapping(const std::string& path)
{
	std::ifstream room_mapping_file(path);
	njson node;
	room_mapping_file >> node;
	
	// convert from (string, string) to (int, string)
	std::map<std::string, int> room_mapping;

	for (const auto& [key, value] : node.items())
	{
		int room_number = std::stoi(key);
		std::string room_name = value;
		room_mapping.emplace(room_name, room_number);
	}

	return room_mapping;
}

void Scene::parse_room(const njson& node)
{
	Room room;
	room.id = node["instanceid"];
	room.translation = std_to_vec3(node["pos"]);
	room.rotation = std_to_quat(node["rot"]);
	room.scale = std_to_vec3(node["scale"]);
	room.category = node["type"];

	for (const auto& child : node["children"])
	{
		const std::string reference = child["ref"];

		// check if structure or furniture
		if (structures.find(reference) != structures.end())
		{
			auto element = structures[reference];
			room.structures.emplace(element.uid, element);

		}
		else if (furniture.find(reference) != furniture.end())
		{
			Element element = furniture[reference];
			
			// transform
			element.translation = std_to_vec3(child["pos"]);
			element.rotation = std_to_quat(child["rot"]);
			element.scale = std_to_vec3(child["scale"]);

			mat4f transform = mat4f::translation(element.translation) * element.rotation.matrix4x4() * mat4f::scale(element.scale);
			element.mesh.transform(transform);

			// assign label
			unsigned short semantic_label = 0;
			category_mapping.getIdForLabel(element.category, semantic_label);
			const auto instance_label = instance_counter;
			assign_labels_to_mesh(element.mesh, semantic_label, instance_label);
			instance_counter++;

			// define unique name and increase instance counter for object
			std::string instance_name = element.category;
			if (instance_object_counter.find(element.category) != instance_object_counter.end()) {
				const auto current_model_counter = instance_object_counter[element.category];
				const auto suffix = util::zeroPad(current_model_counter, 3);
				instance_name = instance_name + "." + suffix;
				instance_object_counter[element.category] = current_model_counter + 1;
			}
			else {
				instance_object_counter.emplace(element.category, 1);
			}

			const std::string instance_id = child["instanceid"];
			room.furniture.emplace(instance_id, element);
			instance_name_instance_id_mapping.emplace(instance_id, instance_label);
		}

	}

	rooms.emplace(room.id, room);
}


void Scene::load_room_structures(Room& room, const std::string& room_folder)
{
	// load all objects in folder
	const fs::path folder{ room_folder };

	for (const auto& file : fs::directory_iterator(folder) )
	{
		// load element
		MeshDataf mesh = MeshIOf::loadFromFile(file.path(), true);
		if (mesh.isConsistent() == false || mesh.isTriMesh() == false)
		{
			mesh.makeTriMesh();
		}

		// convert from blender coord to default coords
		// rotate around x and flip
		mat4f blender_transform = mat4f::rotationX(90) * mat4f::scale(1.0, 1.0, -1.0);
		
		mesh.applyTransform(blender_transform);

		// parse name
		const std::string name = file.path().stem();
		const std::string category = util::splitOnFirst(file.path().stem(), "_").first;


		// assign category (vertex color) to mesh
		Element element;
		element.uid = name;
		element.category = category;
		element.mesh = mesh;
		
		const int semantic_label = structure_category_mapping[category];
		const int instance_label = instance_counter; // doent assign instances to structures
		assign_labels_to_mesh(element.mesh, semantic_label, instance_label);
		instance_counter++;

		// add to room structures
		room.structures.emplace(name, element);
		const std::string instance_id = room.id + "/" + name;
		instance_name_instance_id_mapping.emplace(instance_id, instance_label);
	}
}


void Scene::assign_labels_to_mesh(TriMeshf& mesh, const int& semantic_label, const int& instance_label)
{	
	const auto label = 1000.0 * semantic_label + instance_label;

	for (auto& vertex : mesh.m_vertices)
	{
		
		vertex.color = vec4f(1.0, 1.0, 1.0, label);
	}
	mesh.m_bHasColors = true;
}

MeshDataf Scene::get_room_mesh(const std::string& room_name)
{
	const auto& room = rooms[room_name];

	MeshDataf room_mesh;

	for (const auto& mesh : room.structures)
	{
		const auto mesh_data = mesh.second.mesh.computeMeshData();
		room_mesh.merge(mesh_data);
	}
	for (const auto& mesh : room.furniture)
	{
		const auto mesh_data = mesh.second.mesh.computeMeshData();
		room_mesh.merge(mesh_data);
	}

	mat4f flip = mat4f::scale(-1.0, 1.0, 1.0);
	room_mesh.applyTransform(flip);

	mat4f rot = mat4f::rotationY(180);
	room_mesh.applyTransform(rot);
	
	return room_mesh;
}

MeshDataf Scene::get_scene_mesh()
{
	MeshDataf scene;

	for (const auto& room : rooms)
	{
		const auto room_mesh = get_room_mesh(room.first);
		scene.merge(room_mesh);
	}

	return scene;
}
