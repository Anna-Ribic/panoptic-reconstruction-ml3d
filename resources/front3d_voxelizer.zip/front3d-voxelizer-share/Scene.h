#pragma once

#include "json.h"
#include "LabelUtil.h"

struct SceneInfo {
	std::string id;
	vec3f up;
	vec3f front;
	float scaleToMeters;
};

class Object {
public:
	Object(std::string modelId, unsigned short instanceId, unsigned short labelId, TriMeshf triMesh) {
		m_triMesh = triMesh;
		//m_modelToWorld = modelToWorld;
		m_modelId = modelId;
		m_instanceId = instanceId;
		m_labelId = labelId;
	}
	Object(){}

	~Object() {
	}

	const TriMeshf getTriMesh() const{
		return m_triMesh;
	}

	const std::string getModelId() const 
	{
		return m_modelId;
	}

	const mat4f& getModelToWorld() const {
		return m_modelToWorld;
	}

	unsigned short getLabelId() {
		return m_labelId;
	}

	unsigned short getInstanceId() {
		return m_instanceId;
	}

private:
	mat4f				m_modelToWorld;
	TriMeshf			m_triMesh;
	std::string			m_modelId;
	unsigned short		m_labelId;
	unsigned short		m_instanceId;
};


struct ObjectMaterial{
	std::unordered_map<std::string, std::string> data;
};

class SceneGraphNode {
public:
	SceneGraphNode() {
		id = "";
		type = "";
		valid = true;
		modelId = "";
		state = 0;
		transform = mat4f::identity();
		isMirrored = false;
		dimensions = vec3f(0.0f, 0.0f, 0.0f);
		hideCeiling = false;
		hideFloor = false;
		hideWalls = false;
		//hide[0] = false;
		//hide[1] = false;
		//hide[2] = false;
	}

	int node_index = 0;
	std::string id;
	std::string type;
	bool valid;
	std::string modelId;
	bbox3f bbox;


	//for rooms
	std::vector<unsigned int> nodeIndices;
	std::vector<std::string> roomTypes;
	union {
		bool hideCeiling, hideFloor, hideWalls; //needs to match with mesh creation { "c", "f", "w" };
		bool hide[3] = { false, false, false };
	};

	//for objects
	int state;
	mat4f transform;
	bool isMirrored;
	std::vector<ObjectMaterial> materials;

	//for box
	vec3f dimensions;
};


class Scene
{
public:
	Scene() {
	}

	~Scene() {
	}

	void loadFromJson(const std::string& filename, const std::string& front3dPath, const LabelUtil& front3d2index, const LabelUtil& index2nyuClass, const LabelUtil& nyu40mapping, bool printWarnings = false);

	template<typename T>
	void parseSceneGraphNode(const rapidjson::GenericValue<T>& d, SceneGraphNode& node) {
		node.id = d["id"].GetString();
		if (d.HasMember("bbox")) json::fromJSON(d["bbox"], node.bbox);
		//if (d.HasMember("valid")) node.valid = (bool)d["valid"].GetInt();
		if (d.HasMember("valid")) node.valid = (d["valid"].GetInt() > 0) ? true : false;
		if (d.HasMember("modelId")) node.modelId = d["modelId"].GetString();
		if (d.HasMember("type")) {
			node.type = d["type"].GetString();
			if (node.type == "Room") {
				if (d.HasMember("nodeIndices")) {
					const auto& nodeIndices = d["nodeIndices"];
					node.nodeIndices.resize(nodeIndices.Size());
					for (unsigned int i = 0; i < nodeIndices.Size(); i++)
						node.nodeIndices[i] = (unsigned int)nodeIndices[i].GetInt();
				}
				if (d.HasMember("roomTypes")) {
					const auto& roomTypes = d["roomTypes"];
					node.roomTypes.resize(roomTypes.Size());
					for (unsigned int i = 0; i < roomTypes.Size(); i++)
						node.roomTypes[i] = roomTypes[i].GetString();
				}
				bool ignore_hide_state = true;

				if (ignore_hide_state) {
					if (d.HasMember("hideCeiling")) node.hideCeiling = false;
					if (d.HasMember("hideFloor")) node.hideFloor = false;
					if (d.HasMember("hideWalls")) node.hideWalls = false;
				}
				else {
					if (d.HasMember("hideCeiling")) node.hideCeiling = (d["hideCeiling"].GetInt() > 0) ? true : false;
					if (d.HasMember("hideFloor")) node.hideFloor = (d["hideFloor"].GetInt() > 0) ? true : false;
					if (d.HasMember("hideWalls")) node.hideWalls = (d["hideWalls"].GetInt() > 0) ? true : false;
				}
				
			}
			else if (node.type == "Object") {
				if (d.HasMember("state"))		node.state = d["state"].GetInt();
				//if (d.HasMember("isMirrored"))	node.isMirrored = (bool)d["isMirrored"].GetInt();
				if (d.HasMember("isMirrored"))	node.isMirrored = (d["isMirrored"].GetInt() > 0) ? true : false;
				if (d.HasMember("transform"))	json::fromJSON(d["transform"], node.transform);
				if (d.HasMember("materials")) {
					const auto& materials = d["materials"];
					node.materials.resize(materials.Size());
					for (unsigned int i = 0; i < materials.Size(); i++)
						json::fromJSON(materials[i], node.materials[i].data);
				}
			}
			else if (node.type == "Box") {
				if (d.HasMember("dimensions")) json::fromJSON(d["dimensions"], node.dimensions);
				if (d.HasMember("transform"))	json::fromJSON(d["transform"], node.transform);
				if (d.HasMember("materials")) {
					const auto& materials = d["materials"];
					node.materials.resize(materials.Size());
					for (unsigned int i = 0; i < materials.Size(); i++)
						json::fromJSON(materials[i], node.materials[i].data);
				}
			}
			//else if (node.type == "Ground") {} //nothing special for ground
		}
	}
	
	const MeshDataf& getSceneMesh() const { return m_sceneMesh; }

	void assembleRoomMeshes() {
		// iterate over all room nodes
		for (auto& room_node : m_room_nodes) {
			//std::cout << "Assemble " << room_node.second.modelId << std::endl;
			const auto& node_indices = room_node.second.nodeIndices;

			auto& room_mesh = m_room_meshes[room_node.first];

			// parse room level
			const auto level = util::splitOnFirst(room_node.second.id, "_").first;

			// iterate over all nodeIndices
			for (const auto& node_index : node_indices) {
				// access object in m_objects (check correct index vs nodeIndex
				const auto object = m_level_objects[level][node_index]; // node index counts in the json incl. rooms
				const auto object_mesh = object.getTriMesh();
				
				// merge with room mesh
				room_mesh.merge(object_mesh.computeMeshData());
				
				const auto object_name = object.getModelId();
				m_object_room_mapping[object_name] = room_node.first;
			}

			

		}
	}

	MeshDataf& getRoomMesh(int room_id) { 
		return m_room_meshes[room_id]; 
	}


	void getRoomBboxes(std::vector<bbox3f>& bboxes);

	void addObject(int node_index, std::string node_id, std::string modelId, unsigned short instanceId, unsigned short labelId, TriMeshf trimesh) {
		Object object(modelId, instanceId, labelId, trimesh);
		
		// parse level id; 1_31 --> level 1
		const auto parts = util::splitOnFirst(node_id, "_");
		const auto level = parts.first;

		m_objects.emplace(node_index, object);
		
		m_level_objects[level].emplace(node_index, object);
	}

	const BoundingBox3f& getBoundingBox() const {
		return m_boundingBox;
	}
	std::map<std::string, int> m_object_room_mapping;
	std::unordered_map<int, std::string> m_instance_object_mapping;
	std::map<int, SceneGraphNode> m_room_nodes;
	std::map<int, std::string> m_room_counter_id_mapping;

private:
	void clear() {
		m_sceneMesh.clear();
		m_boundingBox.reset();
		m_sceneGraph.clear();
	}
	BoundingBox3f m_boundingBox;
	MeshDataf m_sceneMesh;
	std::map<int, MeshDataf> m_room_meshes;
	std::map<std::string, TriMeshf> m_structures;
	std::map<int, Object> m_objects;
	std::map<std::string, std::map<int, Object>> m_level_objects;
	std::map<std::string, int> m_model_counter;

	SceneInfo m_sceneInfo;
	std::list<std::list<SceneGraphNode>> m_sceneGraph;
};

