
#pragma once

#include "mLibInclude.h"


class MeshDirectory {
public:
	MeshDirectory() {
	}
	~MeshDirectory() {
	}

	void loadFromList(const std::string& fileList) {
		std::ifstream s(fileList);
		if (!s.is_open()) throw MLIB_EXCEPTION("failed to open " + fileList);
		std::cout << "loading mesh files..." << std::endl;
		std::string meshFile;
		while (std::getline(s, meshFile)) {
			std::vector<std::string> scenes = util::splitPath(meshFile);
			m_imageIds[scenes[0]].push_back(scenes[1]);
		}
		std::cout << "found " << m_imageIds.size() << " mesh files" << std::endl;
	}

	const std::map<std::string, std::vector<std::string>>& get_images() const {
		return m_imageIds;
	}


private:
	std::map<std::string, std::vector<std::string>> m_imageIds;
};