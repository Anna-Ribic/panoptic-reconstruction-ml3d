
#include "stdafx.h"
#include "Scene.h"


void Scene::getRoomBboxes(std::vector<bbox3f>& bboxes) {

	bboxes.clear();
	for (auto& level : m_sceneGraph) {
		for (auto& node : level) {
			if (!node.valid) continue; //ignore invalid
			if (node.type == "") {
				continue;	//if it's the level root ignore it
			}
			else if (node.type == "Room") {
				if (node.bbox.isValid()) bboxes.push_back(node.bbox);
			}
		}
	}
}

void Scene::loadFromJson(const std::string& filename, const std::string& front3dPath, const LabelUtil& front3d2index, const LabelUtil& index2nyuClass, const LabelUtil& nyu40mapping, bool printWarnings){

	const std::string modelDir = "object";
	const std::string roomDir = "room";
	const std::string textureDir = "texture";
	const bool bIgnoreNans = true;
	clear();

	rapidjson::Document d;
	if (!json::parseRapidJSONDocument(filename, &d)) {
		std::cerr << "Parse error reading " << filename << std::endl
			<< "Error code " << d.GetParseError() << " at " << d.GetErrorOffset() << std::endl;
		return;
	}

	m_sceneInfo.id = d["id"].GetString();
	json::fromJSON(d["up"], m_sceneInfo.up);
	json::fromJSON(d["front"], m_sceneInfo.front);
	m_sceneInfo.scaleToMeters = (float)d["scaleToMeters"].GetDouble();
	const auto& json_levels = d["levels"];
	for (unsigned int l = 0; l < json_levels.Size(); l++) {
		SceneGraphNode nodeLevel;
		parseSceneGraphNode(json_levels[l], nodeLevel);
		m_sceneGraph.push_back(std::list<SceneGraphNode>());
		m_sceneGraph.back().push_back(nodeLevel);

		const auto& json_nodes = json_levels[l]["nodes"];
		for (unsigned int n = 0; n < json_nodes.Size(); n++) {
			SceneGraphNode node;
			node.node_index = n;
			parseSceneGraphNode(json_nodes[n], node);
			m_sceneGraph.back().push_back(node);
		}
	}
	unsigned short instanceId = 0; // instance counter
	auto room_counter = 0;
	auto node_counter = 0;
	for (auto& level : m_sceneGraph) {
		const bbox3f bbox = level.front().bbox; //sometimes this can filter out random floating crap
		for (auto& node : level) {
			if (!node.valid) continue; //ignore invalid
			int level_number = -1;
			if (node.type == "") {
				continue;	//if it's the level root ignore it
			}
			else if (node.type == "Room") {
				std::vector<std::string> component = { "c", "f", "w" };
				std::vector<std::string> componentModelIds = { "Ceiling", "Floor", "Wall" };

				for (unsigned int i = 0; i < component.size(); i++) {
					const std::string& c = component[i];
					const std::string meshFilename = front3dPath + "/" + roomDir + "/" + m_sceneInfo.id + "/" + node.modelId + c + ".obj";
					if (node.hide[i] || !util::fileExists(meshFilename)) continue;
					MeshDataf meshDataAll = MeshIOf::loadFromFile(meshFilename, bIgnoreNans);
					const bbox3f meshBbox = meshDataAll.computeBoundingBox();
					if (!bbox.intersects(meshBbox)) { if (printWarnings) std::cout << "warning: skipping mesh (" << node.modelId << ") that falls outside of level bbox" << std::endl; continue; } //skip since outside bbox

					//find label
					unsigned short label = 0;
					std::string className;
					bool bValid = front3d2index.getIdForLabel(componentModelIds[i], label);
					bValid = index2nyuClass.getLabelForId(label, className);
					bValid = nyu40mapping.getIdForLabel(className, label);
					if (!bValid) throw MLIB_EXCEPTION("no label index for " + componentModelIds[i]);

					std::vector< std::pair <MeshDataf, Materialf > > meshDataByMaterial = meshDataAll.splitByMaterial();
					int mesh_counter = 0;
					for (auto& m : meshDataByMaterial) {
						MeshDataf& meshData = m.first;
						MLIB_ASSERT(meshData.isConsistent());
						if (!meshData.isTriMesh()) {
							if (printWarnings) std::cout << "Warning mesh " << meshFilename << " contains non-tri faces (auto-converting)" << std::endl;
							meshData.makeTriMesh();
						}

						MLIB_ASSERT(meshData.isConsistent());
						if (meshData.m_Colors.size() == 0) meshData.m_Colors.resize(meshData.m_Vertices.size(), vec4f(1.0f, 1.0f, 1.0f, 1.0f));	//set default color if none present
						for (auto& c : meshData.m_Colors) c.w = (float)label*1000;
						if (!meshData.hasNormals()) meshData.computeVertexNormals();

						//m_sceneMesh.merge(meshData);
						m_room_meshes[room_counter].merge(meshData);
						const std::string structure_name = node.modelId + "_" + c + "_" + std::to_string(mesh_counter);
						m_structures.emplace(structure_name, TriMeshf(meshData));
						mesh_counter++;
					}

				}
				m_room_nodes[room_counter] = node;
				m_room_counter_id_mapping.emplace(room_counter, node.modelId);
				room_counter++;

			}
			else if (node.type == "Object") {
				instanceId++;
				std::string meshFilename = front3dPath + "/" + modelDir + "/" + node.modelId + "/" + node.modelId + ".obj";
				const std::string mesh_stateful_Filename = front3dPath + "/" + modelDir + "/" + node.modelId + "/" + node.modelId + "_0.obj";

				// Always try to load closed meshes
				if (ml::util::fileExists(mesh_stateful_Filename) == true) {
					meshFilename = mesh_stateful_Filename;
				}

				MeshDataf meshDataAll = MeshIOf::loadFromFile(meshFilename, bIgnoreNans);
				meshDataAll.applyTransform(node.transform);
				const bbox3f meshBbox = meshDataAll.computeBoundingBox();
				if (!bbox.intersects(meshBbox)) { if (printWarnings) std::cout << "warning: skipping mesh (" << node.modelId << ") that falls outside of level bbox" << std::endl; continue; } //skip since outside bbox

				//find label
				unsigned short label = 0;
				std::string className;
				bool bValid = front3d2index.getIdForLabel(node.modelId, label);
				bValid = index2nyuClass.getLabelForId(label, className);
				bValid = nyu40mapping.getIdForLabel(className, label);
				if (!bValid) throw MLIB_EXCEPTION("no label index for " + node.modelId);

				// ignore person class
				if (className == "person") {
					if (printWarnings) std::cout << "warning: skipping mesh (" << node.modelId << ") sinde 'person' is ignored" << std::endl; 
					continue;
				}

				std::vector< std::pair <MeshDataf, Materialf > > meshDataByMaterial = meshDataAll.splitByMaterial();
				MeshDataf object_mesh;
				for (auto& m : meshDataByMaterial) {
					MeshDataf& meshData = m.first;
					MLIB_ASSERT(meshData.isConsistent());
					if (!meshData.isTriMesh()) {
						if (printWarnings) std::cout << "Warning mesh " << meshFilename << " contains non-tri faces (auto-converting)" << std::endl;
						meshData.makeTriMesh();
					}

					MLIB_ASSERT(meshData.isConsistent());
					if (meshData.m_Colors.size() == 0) meshData.m_Colors.resize(meshData.m_Vertices.size(), vec4f(1.0f, 1.0f, 1.0f, 1.0f));	//set default color if none present
					unsigned int combinedId = (unsigned int)label * 1000u + (unsigned int)instanceId;
					for (auto& c : meshData.m_Colors) c.w = (float)combinedId;
					if (!meshData.hasNormals()) meshData.computeVertexNormals();

					//m_sceneMesh.merge(meshData);
					object_mesh.merge(meshData);
				}
				
				TriMeshf triMesh(object_mesh);

				std::string instance_name = node.modelId;

				// if model was already loaded, append counter to modelid
				if (m_model_counter.find(node.modelId) != m_model_counter.end()) {
					const auto current_model_counter = m_model_counter[node.modelId];
					const auto suffix = util::zeroPad(current_model_counter, 3);
					instance_name = instance_name + "." + suffix;
					m_model_counter[node.modelId] = current_model_counter + 1;
				}
				else {
					m_model_counter.emplace(node.modelId, 1);
				}

				addObject(node.node_index, node.id, instance_name, instanceId, label, triMesh);
				m_instance_object_mapping[instanceId] = instance_name;

			}
			else if (node.type == "Box") { //TODO HERE ANGIE
				const std::string meshFilename = front3dPath + "/" + modelDir + "/mgcube/mgcube.obj";
				MeshDataf meshDataAll = MeshIOf::loadFromFile(meshFilename, bIgnoreNans);
				meshDataAll.applyTransform(mat4f::scale(node.dimensions));
				meshDataAll.applyTransform(node.transform);
				const bbox3f meshBbox = meshDataAll.computeBoundingBox();
				if (!bbox.intersects(meshBbox)) { if (printWarnings) std::cout << "warning: skipping mesh (" << node.modelId << ") that falls outside of level bbox" << std::endl; continue; } //skip since outside bbox
				//find label
				unsigned short front3d_id = 0;
				std::string className;
				bool bValid = front3d2index.getIdForLabel(node.type, front3d_id);
				bValid = index2nyuClass.getLabelForId(front3d_id, className);

				unsigned short nyu_label = 0;
				bValid = nyu40mapping.getIdForLabel(className, nyu_label);
				if (!bValid) throw MLIB_EXCEPTION("no label index for " + node.type);


				std::vector< std::pair <MeshDataf, Materialf > > meshDataByMaterial = meshDataAll.splitByMaterial();
				for (unsigned int i = 0; i < meshDataByMaterial.size(); i++) {
					MeshDataf& meshData = meshDataByMaterial[i].first;
					Materialf& material = meshDataByMaterial[i].second;
					MLIB_ASSERT(meshData.isConsistent());
					if (!meshData.isTriMesh()) {
						if (printWarnings) std::cout << "Warning mesh " << meshFilename << " contains non-tri faces (auto-converting)" << std::endl;
						meshData.makeTriMesh();
					}
					MLIB_ASSERT(meshData.isConsistent());
					if (meshData.m_Colors.size() == 0) meshData.m_Colors.resize(meshData.m_Vertices.size(), vec4f(1.0f, 1.0f, 1.0f, 1.0f));	//set default color if none present
					for (auto& c : meshData.m_Colors) c.w = (float)nyu_label*1000;
					if (!meshData.hasNormals()) meshData.computeVertexNormals();

					//m_sceneMesh.merge(meshData);
				}
			}
			else if (node.type == "Ground") {
				const std::string meshFilename = front3dPath + "/" + roomDir + "/" + m_sceneInfo.id + "/" + node.modelId + "f.obj";
				MeshDataf meshDataAll = MeshIOf::loadFromFile(meshFilename, bIgnoreNans);
				const bbox3f meshBbox = meshDataAll.computeBoundingBox();
				if (!bbox.intersects(meshBbox)) { if (printWarnings) std::cout << "warning: skipping mesh (" << node.modelId << ") that falls outside of level bbox" << std::endl; continue; } //skip since outside bbox
				//find label
				unsigned short label = 0;
				std::string className;
				bool bValid = front3d2index.getIdForLabel("Floor", label);
				bValid = index2nyuClass.getLabelForId(label, className);
				bValid = nyu40mapping.getIdForLabel(className, label);
				if (!bValid) throw MLIB_EXCEPTION("no label index for " + node.type);

				std::vector< std::pair <MeshDataf, Materialf > > meshDataByMaterial = meshDataAll.splitByMaterial();
				for (auto& m : meshDataByMaterial) {

					MeshDataf& meshData = m.first;
					Materialf& material = m.second;

					MLIB_ASSERT(meshData.isConsistent());
					if (!meshData.isTriMesh()) {
						if (printWarnings) std::cout << "Warning mesh " << meshFilename << " contains non-tri faces (auto-converting)" << std::endl;
						meshData.makeTriMesh();
					}
					MLIB_ASSERT(meshData.isConsistent());
					if (meshData.m_Colors.size() == 0) meshData.m_Colors.resize(meshData.m_Vertices.size(), vec4f(1.0f, 1.0f, 1.0f, 1.0f));	//set default color if none present
					for (auto& c : meshData.m_Colors) c.w = (float)label*1000u;
					if (!meshData.hasNormals()) meshData.computeVertexNormals();

					//m_sceneMesh.merge(meshData);
				}
			}
			else {
				throw MLIB_EXCEPTION("unknown type: " + node.type);
			}//
		} //
	}  //
}   //
    //