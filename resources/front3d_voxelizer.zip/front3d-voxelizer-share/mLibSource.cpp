
#include "stdafx.h"

#include "mLibCore.cpp"
#include "mLibDepthCamera.cpp"