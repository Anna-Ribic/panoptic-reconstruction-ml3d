//
// external FreeImage headers
//
//#include "FreeImage.h"
#include "FreeImage/FreeImage.h"
//#include <wchar.h>

//
// ext-FreeImage headers
//
#include "ext-freeimage/freeImageWrapper.h"
