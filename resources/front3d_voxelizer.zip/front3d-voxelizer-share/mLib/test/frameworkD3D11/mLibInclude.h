
//
// mLib config options
//

#define MLIB_ERROR_CHECK
#define MLIB_BOUNDS_CHECK

//
// mLib includes
//

#include "mLibCore.h"
#include "mLibD3D11.h"
#include "mLibD3D11Font.h"

using namespace ml;