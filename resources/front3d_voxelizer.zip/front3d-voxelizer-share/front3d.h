#pragma once

#include <string>
#include <map>

#include "mLibInclude.h"

#include "LabelUtil.h"

#include "nlohmann/json.hpp"

using njson = nlohmann::json;

namespace Front3D 
{
	class Element
	{
	public:
		std::string jid{ "" };
		std::string uid{ "" };
		std::string category{ "" };
		std::string style{ "" };

		vec3f translation;
		vec3f scale;
		quatf rotation;

		bool valid{ false };

		TriMeshf mesh;
	};


	class Room
	{
	public:
		std::string id{ "" };
		std::string category{ "" };
		std::map<std::string, Element> structures;
		std::map<std::string, Element> furniture;

		vec3f translation;
		vec3f scale;
		quatf rotation;

	};


	class Scene
	{
	public:

		void load_from_json(const std::string& scene_file, const std::string& shape_path, const std::string& scene_image_path, const std::string& category_mapping_path);
		void parse_and_load_furniture(const njson& node, const std::string& furniture_path);
		void parse_meshes(const njson& node);
		void parse_mesh(const njson& node);
		bool is_excluded_mesh_type(const std::string& mesh_type) const;
		
		std::map<std::string, int> load_room_mapping(const std::string& path);
		void parse_room(const njson& node);
		void load_room_structures(Room& room, const std::string& room_path);

		void assign_labels_to_mesh(TriMeshf& mesh, const int& semantic_label, const int& instance_label);

		MeshDataf get_room_mesh(const std::string& room_name);
		MeshDataf get_scene_mesh();

		std::string id;
		std::map<std::string, Element> furniture;
		std::map<std::string, Element> structures;
		std::map<std::string, Room> rooms;
		std::map<int, std::string> room_index_mapping;

		std::map<std::string, int> instance_object_counter;
		std::map<int, std::string> instance_object_mapping;
		std::map<std::string, int> instance_name_instance_id_mapping;

		std::vector<std::string> excluded_mesh_types = { "WallOuter", "WallBottom", "WallTop", "Pocket", "SlabSide", "SlabBottom", "SlabTop",
										"Front", "Back", "Baseboard", "Door", "Window", "BayWindow", "Hole", "WallInner", "Beam" };

		std::map<std::string, int> structure_category_mapping = { {"wall", 13}, {"ceiling", 38}, {"floor", 45} };
		LabelUtil category_mapping;

		vec3f translation;
		vec3f scale;
		quatf rotation;

		int instance_counter = 1;
	};
}

