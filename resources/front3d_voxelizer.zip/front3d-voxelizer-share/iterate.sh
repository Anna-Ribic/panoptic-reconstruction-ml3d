#!/bin/bash

# Assuming your method is called using ".frv" and takes the filename without the extension as an argument
METHOD_NAME="./frv"

# Change the directory path as needed
DIRECTORY_PATH="../output3/"

# Iterate over all JSON files in the directory
for json_file in "$DIRECTORY_PATH"/*.json; do
    # Check if the file exists and is a regular file
    if [ -f "$json_file" ]; then
        # Extract the filename without extension
        filename=$(basename "$json_file" .json)
        echo "Processing $json_file..."

        # Call your method with the filename
        $METHOD_NAME "$filename"
    fi
done
