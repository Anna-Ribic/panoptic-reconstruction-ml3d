#include "stdafx.h"
#include "MeshDirectory.h"
#include "Scene.h"
#include "makelevelset3.h"
#include "omp.h"
#include "GlobalAppState.h"
#include <random>
#include <algorithm>
#include "core-util/utility.h"
#include "cnpy/cnpy.h"
#include "nlohmann/json.hpp"
#include "front3d.h"
#include <cmath>
using njson = nlohmann::json;


MeshDataf visualize_frustum(const std::vector<vec3f>& points) 
{
	std::vector<LineSegment3f> edges;

	edges.push_back(LineSegment3f(points[0], points[1]));
	edges.push_back(LineSegment3f(points[1], points[2]));
	edges.push_back(LineSegment3f(points[2], points[3]));
	edges.push_back(LineSegment3f(points[3], points[0]));

	edges.push_back(LineSegment3f(points[4], points[5]));
	edges.push_back(LineSegment3f(points[5], points[6]));
	edges.push_back(LineSegment3f(points[6], points[7]));
	edges.push_back(LineSegment3f(points[7], points[4]));

	edges.push_back(LineSegment3f(points[0], points[4]));
	edges.push_back(LineSegment3f(points[1], points[5]));
	edges.push_back(LineSegment3f(points[2], points[6]));
	edges.push_back(LineSegment3f(points[3], points[7]));
	

	// normals
	vec3f normal_front = ((points[3] - points[0]) ^ (points[1] - points[0])).getNormalized();
	vec3f center_front = points[0] + ((points[2] - points[0]) / 2.0f);
	edges.push_back(LineSegment3f(center_front, center_front + normal_front));

	MeshDataf result;
	const RGBColor c = RGBColor::colorPalette(0);
	for (const auto& e : edges)
	{
		result.merge(Shapesf::cylinder(e.p0(), e.p1(), 0.1, 10, 10, c).computeMeshData());
	}

	return result;

}

void visualizeAABBs(const std::vector<bbox3f>& rooms, MeshDataf& meshAABBs){
	for (unsigned int i = 0; i < rooms.size(); i++) {
		bbox3f aabbGrid = rooms[i];
		const RGBColor c = RGBColor::colorPalette(i);
		for (const LineSegment3f& e : aabbGrid.getEdges()) meshAABBs.merge(Shapesf::cylinder(e.p0(), e.p1(), 0.05, 10, 10, c).computeMeshData());
	}
}

void saveSemanticsToFileDense(std::string filename, Grid3<unsigned int> sem)
{
	std::ofstream ofs(filename, std::ios::binary);
	//dense data
	UINT64 dimX = sem.getDimX(), dimY = sem.getDimY(), dimZ = sem.getDimZ();
	ofs.write((const char*)&dimX, sizeof(UINT64));
	ofs.write((const char*)&dimY, sizeof(UINT64));
	ofs.write((const char*)&dimZ, sizeof(UINT64));
	ofs.write((const char*)sem.getData(), sizeof(unsigned int) * sem.getNumElements());
	ofs.close();

}


void saveSemanticsToFileSparse(std::string filename, Grid3<unsigned int> sem)
{
	std::ofstream ofs(filename, std::ios::binary);
	
	// header data
	UINT64 dimX = sem.getDimX(), dimY = sem.getDimY(), dimZ = sem.getDimZ();
	ofs.write((const char*)&dimX, sizeof(UINT64));
	ofs.write((const char*)&dimY, sizeof(UINT64));
	ofs.write((const char*)&dimZ, sizeof(UINT64));

	// collect occupied voxels
	std::vector<vec3ui> locations;
	std::vector<unsigned int> labels;

	const unsigned int freespace_label = 0;

	for (const auto& voxel : sem)
	{
		if (voxel.value != freespace_label)
		{
			locations.emplace_back(voxel.x, voxel.y, voxel.z);
			labels.emplace_back(voxel.value);
		}
	}

	// save voxels
	UINT64 num_voxels = (UINT64)locations.size();
	ofs.write((const char*)&num_voxels, sizeof(UINT64));
	ofs.write((const char*)locations.data(), sizeof(vec3ui) * locations.size());
	ofs.write((const char*)labels.data(), sizeof(unsigned int) * labels.size());

	ofs.close();

}

void saveSemanticsToFile(std::string filename, Grid3<unsigned int> sem, bool sparse) 
{
	if (sparse == true)
	{
		saveSemanticsToFileSparse(filename, sem);
	}
	else
	{
		saveSemanticsToFileDense(filename, sem);
	}

}



void save_box(std::string filename, bbox3f bbox)
{
	std::ofstream ofs(filename, std::ios::binary);
	//dense data
	vec3f min = bbox.getMin();
	vec3f max = bbox.getMax();
	ofs.write((const char*)min.getData(), sizeof(float)*3);
	ofs.write((const char*)max.getData(), sizeof(float)*3);
	ofs.close();


}

void saveDistanceFieldDense(const std::string& filename, const DistanceField3f& df)
{
	std::ofstream ofs(filename, std::ios::binary);
	//dense data
	UINT64 dimX = df.getDimX(), dimY = df.getDimY(), dimZ = df.getDimZ();
	ofs.write((const char*)&dimX, sizeof(UINT64));
	ofs.write((const char*)&dimY, sizeof(UINT64));
	ofs.write((const char*)&dimZ, sizeof(UINT64));
	ofs.write((const char*)df.getData(), sizeof(float) * df.getNumElements());
	ofs.close();
}

void saveDistanceFieldSparse(const std::string& filename, const DistanceField3f& df, float truncation)
{
	std::ofstream ofs(filename, std::ios::binary);

	// header data
	UINT64 dimX = df.getDimX(), dimY = df.getDimY(), dimZ = df.getDimZ();
	ofs.write((const char*)&dimX, sizeof(UINT64));
	ofs.write((const char*)&dimY, sizeof(UINT64));
	ofs.write((const char*)&dimZ, sizeof(UINT64));

	std::cout << "X: " << dimX << "\tY: " << dimY << "\tZ: " << dimZ << "\t";

	// collect occupied voxels
	std::vector<vec3ui> locations;
	std::vector<float> distance_values;

	const unsigned int freespace_label = 0;

	for (const auto& voxel : df)
	{
		if (abs(voxel.value) < truncation)
		{
			locations.emplace_back(voxel.x, voxel.y, voxel.z);
			distance_values.emplace_back(voxel.value);
		}
	}

	// save voxels
	UINT64 num_voxels = (UINT64)locations.size();
	ofs.write((const char*)&num_voxels, sizeof(UINT64));
	ofs.write((const char*)locations.data(), sizeof(vec3ui) * locations.size());
	ofs.write((const char*)distance_values.data(), sizeof(float) * distance_values.size());

	ofs.close();
}

void saveDistanceField(const std::string& filename, const DistanceField3f& df, bool sparse, float truncation)
{
	
	if (sparse)
	{
		saveDistanceFieldSparse(filename, df, truncation);
	}
	else 
	{
		saveDistanceFieldDense(filename, df);
	}
}




void loadDistanceField(const std::string& filename, DistanceField3f& df, bbox3f& bbox, float& voxelSize)
{
	std::ifstream ifs(filename, std::ios::binary);
	//metadata
	UINT64 dimX, dimY, dimZ;
	ifs.read((char*)&dimX, sizeof(UINT64));
	ifs.read((char*)&dimY, sizeof(UINT64));
	ifs.read((char*)&dimZ, sizeof(UINT64));
	ifs.read((char*)&voxelSize, sizeof(float));
	vec3f bmin, bmax;
	ifs.read((char*)&bmin.x, sizeof(float));
	ifs.read((char*)&bmin.y, sizeof(float));
	ifs.read((char*)&bmin.z, sizeof(float));
	ifs.read((char*)&bmax.x, sizeof(float));
	ifs.read((char*)&bmax.y, sizeof(float));
	ifs.read((char*)&bmax.z, sizeof(float));
	bbox = bbox3f(bmin, bmax);
	//dense data
	df.allocate(dimX, dimY, dimZ);
	ifs.read((char*)df.getData(), sizeof(float)*df.getNumElements());
	ifs.close();
}


unsigned int computeLabel(const vec3ui& location, const Grid3<unsigned int>& labels, bool& ok) {
	unsigned int label = labels(location);
	if (label > 0) return label;

	const int searchRadius = 3;
	float minDistSq = std::numeric_limits<float>::infinity();
	for (int zz = -searchRadius; zz <= searchRadius; zz++) {
		for (int yy = -searchRadius; yy <= searchRadius; yy++) {
			for (int xx = -searchRadius; xx <= searchRadius; xx++) {
				vec3i coord((int)location.x + xx, (int)location.y + yy, (int)location.z + zz);
				if (labels.isValidCoordinate(coord)) {
					unsigned int l = labels(coord);
					if (l > 0) {
						float dist = vec3f::distSq(coord, location);
						if (dist < minDistSq) {
							label = l;
							minDistSq = dist;
						}
					}
				}
			}
		}
	}
	if (label == 0) {
		ok = false;
	}

	ok = true;
	return label;
}

void voxelizeTriangle(const vec3f& v0, const vec3f& v1, const vec3f& v2, unsigned int id, Grid3<unsigned int>& grid, bool solid /*= false*/)
{
	const size_t depth = grid.getDimZ();
	float diagLenSq = 3.0f;
	if ((v0 - v1).lengthSq() < diagLenSq && (v0 - v2).lengthSq() < diagLenSq && (v1 - v2).lengthSq() < diagLenSq) {
		bbox3f bb(v0, v1, v2);
		vec3ui minI = math::floor(bb.getMin());
		vec3ui maxI = math::ceil(bb.getMax());
		minI = vec3ui(math::clamp(minI.x, 0u, (unsigned int)grid.getDimX()), math::clamp(minI.y, 0u, (unsigned int)grid.getDimY()), math::clamp(minI.z, 0u, (unsigned int)grid.getDimZ()));
		maxI = vec3ui(math::clamp(maxI.x, 0u, (unsigned int)grid.getDimX()), math::clamp(maxI.y, 0u, (unsigned int)grid.getDimY()), math::clamp(maxI.z, 0u, (unsigned int)grid.getDimZ()));

		//test for accurate voxel-triangle intersections
		for (unsigned int i = minI.x; i <= maxI.x; i++) {
			for (unsigned int j = minI.y; j <= maxI.y; j++) {
				for (unsigned int k = minI.z; k <= maxI.z; k++) {
					vec3f v(i, j, k);
					bbox3f voxel;
					const float eps = 0.0000f;
					voxel.include((v - 0.5f - eps));
					voxel.include((v + 0.5f + eps));
					if (voxel.intersects(v0, v1, v2)) {
						if (solid) {
							//project to xy-plane
							vec2f pv = v.getVec2();
							if (intersection::intersectTrianglePoint(v0.getVec2(), v1.getVec2(), v2.getVec2(), pv)) {
								Rayf r0(vec3f(v), vec3f(0, 0, 1));
								Rayf r1(vec3f(v), vec3f(0, 0, -1));
								float t0, t1, _u0, _u1, _v0, _v1;
								bool b0 = intersection::intersectRayTriangle(v0, v1, v2, r0, t0, _u0, _v0);
								bool b1 = intersection::intersectRayTriangle(v0, v1, v2, r1, t1, _u1, _v1);
								if ((b0 && t0 <= 0.5f) || (b1 && t1 <= 0.5f)) {
									if (i < grid.getDimX() && j < grid.getDimY() && k < grid.getDimZ()) {
										//grid.toggleVoxelAndBehindSlice(i, j, k);
										for (size_t kk = k; kk < depth; kk++) {
											grid(i, j, kk) = id;
										}
									}
								}
								//grid.setVoxel(i,j,k);
							}
						}
						else {
							if (i < grid.getDimX() && j < grid.getDimY() && k < grid.getDimZ()) {
								grid(i, j, k) = id;
							}
						}
					}
				}
			}
		}
	}
	else {
		vec3f e0 = (float)0.5f*(v0 + v1);
		vec3f e1 = (float)0.5f*(v1 + v2);
		vec3f e2 = (float)0.5f*(v2 + v0);
		voxelizeTriangle(v0, e0, e2, id, grid, solid);
		voxelizeTriangle(e0, v1, e1, id, grid, solid);
		voxelizeTriangle(e1, v2, e2, id, grid, solid);
		voxelizeTriangle(e0, e1, e2, id, grid, solid);
	}
}

void voxelize(Grid3<unsigned int>& grid, const TriMeshf& triMesh, const mat4f& worldToVoxel /*= mat4f::identity()*/, bool solid /*= false*/, bool verbose /*= true*/)
{
	grid.setValues(0);
	for (size_t i = 0; i < triMesh.m_indices.size(); i++) {
		vec3f p0 = worldToVoxel * triMesh.m_vertices[triMesh.m_indices[i].x].position;
		vec3f p1 = worldToVoxel * triMesh.m_vertices[triMesh.m_indices[i].y].position;
		vec3f p2 = worldToVoxel * triMesh.m_vertices[triMesh.m_indices[i].z].position;
		if (std::isnan(p0.x) || std::isnan(p1.x) || std::isnan(p2.x))
			continue;
		unsigned int id = (unsigned int)std::round(triMesh.m_vertices[triMesh.m_indices[i].x].color.w);

		bbox3f bb0(p0, p1, p2);
		bbox3f bb1(vec3f(0, 0, 0), vec3f((float)grid.getDimX() + 1.0f, (float)grid.getDimY() + 1.0f, (float)grid.getDimZ() + 1.0f));
		if (bb0.intersects(bb1)) {
			voxelizeTriangle(p0, p1, p2, id, grid, solid);
		}
		else if (verbose) {
			std::cerr << "out of bounds: " << p0 << "\tof: " << grid.getDimensions() << std::endl;
			std::cerr << "out of bounds: " << p1 << "\tof: " << grid.getDimensions() << std::endl;
			std::cerr << "out of bounds: " << p2 << "\tof: " << grid.getDimensions() << std::endl;
			MLIB_WARNING("triangle outside of grid - ignored");
		}
	}
}


TriMeshf convertAnnGridToMesh(const Grid3<unsigned int>& annotated, bool show_semantics=false)
{
	TriMeshf triMesh;

	// Pre-allocate space
	size_t nVoxels = 0;
	for (const auto& v : annotated) {
		if (v.value != 0) nVoxels++;
	}
	//std::cout << "Found " << nVoxels << " valid voxels" << std::endl;
	size_t nVertices = nVoxels * 8; //no normals
	size_t nIndices = nVoxels * 12;
	triMesh.m_vertices.reserve(nVertices);
	triMesh.m_indices.reserve(nIndices);
	// Temporaries
	vec3f verts[24];
	vec3ui indices[12];
	vec3f normals[24];
	for (size_t z = 0; z < annotated.getDimZ(); z++) {
		for (size_t y = 0; y < annotated.getDimY(); y++) {
			for (size_t x = 0; x < annotated.getDimX(); x++) {
				unsigned int val = annotated(x, y, z);
				if (val != 0) {
					vec3f p(x, y, z);
					vec3f pMin = p - 0.45f;//0.5f;
					vec3f pMax = p + 0.45f;//0.5f;
					bbox3f bb(pMin, pMax);
					bb.makeTriMesh(verts, indices);

					unsigned int vertIdxBase = static_cast<unsigned int>(triMesh.m_vertices.size());
					for (size_t i = 0; i < 8; i++) {
						
						//if (val == 255) {
						//	triMesh.m_vertices.back().color = vec4f(0.0f, 0.0f, 0.0f, 0.0f); //black for no annotation
						//}
						//else {
							const unsigned int instance_id = val % 1000;
							const unsigned int semantic_id = math::floor(val / 1000);
							RGBColor color;
							
							if (show_semantics == true) {
								color = RGBColor::colorPalette(semantic_id);
							}
							else {
								color = RGBColor::colorPalette(instance_id);

							}
							
							TriMeshf::Vertex v(verts[i]);
							v.color = color;
							triMesh.m_vertices.emplace_back(v);

					for (size_t i = 0; i < 12; i++) {
						indices[i] += vertIdxBase;
						triMesh.m_indices.emplace_back(indices[i]);
					}}
				}
			}
		}
	}
	triMesh.setHasColors(true);
	return triMesh;
}



void loadGlobalAppState(const std::string& fileNameDescGlobalApp) {
	if (!util::fileExists(fileNameDescGlobalApp)) {
		throw MLIB_EXCEPTION("cannot find parameter filer " + fileNameDescGlobalApp);
	}

	std::cout << VAR_NAME(fileNameDescGlobalApp) << " = " << fileNameDescGlobalApp << std::endl;
	ParameterFile parameterFileGlobalApp(fileNameDescGlobalApp);
	GlobalAppState::get().readMembers(parameterFileGlobalApp);
	GlobalAppState::get().print();

}

/*void load_instance(std::string& instancePath, std::set<unsigned int>& instanceIds, int minCount=0)
{

	DepthImage16 instance;
	FreeImageWrapper::loadImage(instancePath, *(DepthImage16*)&instance);

	std::map<unsigned int, unsigned int> dict;
	
	for (int i = 0; i < instance.getWidth()*instance.getHeight(); i++)
	{
		unsigned int instanceId = instance.getData()[i];
		if (!dict.count(instanceId))
			dict[instanceId] = 0;
		dict[instanceId] += 1;
	}

	for (auto item : dict)
		if (item.second > minCount)
			instanceIds.emplace(item.first);

}*/

void write_files(const std::string& filename, const std::vector<std::string>& files)
{

	std::ofstream ofs(filename);
	if (!ofs.is_open()) throw "failed to open " + filename;
	for (auto line : files)
		ofs << line + "\n";
	ofs.close();
}

void load_pose(const std::string& posePath, mat4f& pose)
{

	std::ifstream ifs(posePath);
	if (!ifs.is_open()) throw "failed to open " + posePath;
	std::string line;
	for (unsigned int r = 0; r < 4; r++) {
		std::getline(ifs, line);
		auto numbers = util::split(line, " ");
		pose(r, 0) = std::stof(numbers[0]);
		pose(r, 1) = std::stof(numbers[1]);
		pose(r, 2) = std::stof(numbers[2]);
		pose(r, 3) = std::stof(numbers[3]);
	}
	ifs.close();

}

bbox3f compute_frustum(float depthMin, float depthMax, mat4f intrinsicInv, std::vector<float> imageSize)
{
	float x = imageSize[0];
	float y = imageSize[1];


	vec4f point1(0 * depthMin, 0 * depthMin, depthMin, 1.0);
	vec4f point2(0 * depthMin, y*depthMin, depthMin, 1.0);
	vec4f point3(x*depthMin, y*depthMin, depthMin, 1.0);
	vec4f point4(x*depthMin, 0 * depthMin, depthMin, 1.0);
	vec4f point5(0 * depthMax, 0 * depthMax, depthMax, 1.0);
	vec4f point6(0 * depthMax, y*depthMax, depthMax, 1.0);
	vec4f point7(x*depthMax, y*depthMax, depthMax, 1.0);
	vec4f point8(x*depthMax, 0 * depthMax, depthMax, 1.0);

	point1 = intrinsicInv * point1;
	point2 = intrinsicInv * point2;
	point3 = intrinsicInv * point3;
	point4 = intrinsicInv * point4;
	point5 = intrinsicInv * point5;
	point6 = intrinsicInv * point6;
	point7 = intrinsicInv * point7;
	point8 = intrinsicInv * point8;

	float minx = std::min({ point1[0], point2[0], point3[0], point4[0], point5[0], point6[0], point7[0], point8[0]});
	float miny = std::min({ point1[1], point2[1], point3[1], point4[1], point5[1], point6[1], point7[1], point8[1]});
	float minz = std::min({ point1[2], point2[2], point3[2], point4[2], point5[2], point6[2], point7[2], point8[2]});

	float maxx = std::max({ point1[0], point2[0], point3[0], point4[0], point5[0], point6[0], point7[0], point8[0]});
	float maxy = std::max({ point1[1], point2[1], point3[1], point4[1], point5[1], point6[1], point7[1], point8[1]});
	float maxz = std::max({ point1[2], point2[2], point3[2], point4[2], point5[2], point6[2], point7[2], point8[2]});

	return bbox3f(vec3f(minx, miny, minz), vec3f(maxx, maxy, maxz));
}

std::vector<vec3f> get_frustum_points(const float depth_min, const float depth_max, const mat4f& intrinsic_inv, std::vector<float>& image_size)
{
	float x = image_size[0];
	float y = image_size[1];


	vec3f point1(0 * depth_min, 0 * depth_min, depth_min);
	vec3f point2(0 * depth_min, y * depth_min, depth_min);
	vec3f point3(x * depth_min, y * depth_min, depth_min);
	vec3f point4(x * depth_min, 0 * depth_min, depth_min);
	vec3f point5(0 * depth_max, 0 * depth_max, depth_max);
	vec3f point6(0 * depth_max, y * depth_max, depth_max);
	vec3f point7(x * depth_max, y * depth_max, depth_max);
	vec3f point8(x * depth_max, 0 * depth_max, depth_max);

	point1 = intrinsic_inv * point1;
	point2 = intrinsic_inv * point2;
	point3 = intrinsic_inv * point3;
	point4 = intrinsic_inv * point4;
	point5 = intrinsic_inv * point5;
	point6 = intrinsic_inv * point6;
	point7 = intrinsic_inv * point7;
	point8 = intrinsic_inv * point8;

	return { point1, point2, point3, point4, point5, point6, point7, point8 };
}

Planef plane_from_points(const vec3f& p0, const vec3f& p1, const vec3f& p2) 
{
	vec3f normal = ((p1 - p0) ^ (p2 - p0)).getNormalized();
	float distance = (normal | p0);

	Planef plane(normal, distance);
	return plane;
}

std::vector<Planef> get_frustum_planes(const std::vector<vec3f>& points) {
	Planef near_plane = plane_from_points(points[0], points[3], points[1]);
	Planef far_plane = plane_from_points(points[4], points[5], points[7]);
	Planef left_plane = plane_from_points(points[1], points[5], points[0]);
	Planef right_plane = plane_from_points(points[2], points[3], points[6]);
	Planef top_plane = plane_from_points(points[0], points[4], points[3]);
	Planef bottom_plane = plane_from_points(points[1], points[2], points[5]);


	return { near_plane, far_plane, left_plane, right_plane, top_plane, bottom_plane };
}

bool is_inside_frustum(const std::vector<Planef>& planes, const vec3f& point) 
{
	for (const auto& plane : planes) 
	{
		const auto distance = plane.distanceToPoint(point);
		if (distance < 0.0f)
		{
			return false;
		}
	}

	return true;
}


void filter_instances(TriMeshf& tempTriMesh, const std::set<unsigned int>& instanceIds)
{
	std::vector<vec3ui> tri = tempTriMesh.getIndices();
	auto verts = tempTriMesh.getVertices();
	std::vector<vec3ui> newIndices;

	for (int i = 0; i < tempTriMesh.getIndices().size(); i++)
	{
		unsigned int p = tri[i].x;
		unsigned int q = tri[i].y;
		unsigned int r = tri[i].z;
		if (instanceIds.count((unsigned int)(verts[p].color[3]) % 1000))
			newIndices.push_back(vec3ui(p, q, r));
	}
	tempTriMesh.m_indices = newIndices;

}

void filter_all_instances(TriMeshf& tempTriMesh)
{
	std::vector<vec3ui> tri = tempTriMesh.getIndices();
	auto verts = tempTriMesh.getVertices();
	std::vector<vec3ui> newIndices;

	for (int i = 0; i < tempTriMesh.getIndices().size(); i++)
	{
		unsigned int p = tri[i].x;
		unsigned int q = tri[i].y;
		unsigned int r = tri[i].z;
		if ((unsigned int)(verts[p].color[3]) % 1000 == 0)
			newIndices.push_back(vec3ui(p, q, r));
	}
	tempTriMesh.m_indices = newIndices;

}


bool find_validRooms(TriMeshf& tempTriMesh, const vec3f& origin, const std::vector<bbox3f>& rooms, std::vector<bbox3f>& validRooms, std::set<unsigned int> instanceIds)
{
	// prepare data
	std::vector<vec3ui> tri = tempTriMesh.getIndices();
	auto verts = tempTriMesh.getVertices();
	std::vector<unsigned int> validIds;
	std::map<unsigned int, std::set<unsigned int>> instanceIdsPerRoom;
	std::set<unsigned int> tempInstanceIds;

	//get statistics
	for (int i = 0; i < tempTriMesh.getIndices().size(); i++)
	{
		unsigned int p = tri[i].x;
		unsigned int q = tri[i].y;
		unsigned int r = tri[i].z;
		unsigned int  instanceId = (unsigned int)(verts[p].color[3]) % 1000;

		if (instanceId != 0)
		{
			for (unsigned int j = 0; j < rooms.size(); j++)
				if (rooms[j].intersects(verts[p].position) || rooms[j].intersects(verts[q].position) || rooms[j].intersects(verts[r].position))
				{
					instanceIdsPerRoom[j].emplace(instanceId);
					tempInstanceIds.emplace(instanceId);
				}
		}
	}

	if (tempInstanceIds.size() != instanceIds.size()-1)
	{
		std::cout << "outdoor" << std::endl;
		return false;
	}

	//major room
	for (auto item: instanceIdsPerRoom)
	{
		if (rooms[item.first].intersects(origin))
			validIds.push_back(item.first);
	}
	if (validIds.size() != 1)
	{
		std::cout << "more than 1 major room:" << validIds.size() << std::endl;
		return false;

	}

	//other rooms
	for (unsigned int instanceIdInMajorRoom : instanceIdsPerRoom[validIds[0]])
	{
		for (auto& item : instanceIdsPerRoom)
		{
			if (validIds[0] == item.first)
				continue;
			if (item.second.count(instanceIdInMajorRoom))
				item.second.erase(instanceIdInMajorRoom);
		}

	}
	instanceIdsPerRoom[validIds[0]].clear();

	bool flag = true;
	while (flag)
	{
		int maxNum = 0;
		int roomId = -1;
		for (auto item : instanceIdsPerRoom)
		{
			if (item.second.size() > maxNum)
			{
				roomId = item.first;
				maxNum = item.second.size();
			}
		}
		if (maxNum == 0)
			flag = false;
		else
		{
			validIds.push_back(roomId);
			for (unsigned int instanceIdInMajorRoom : instanceIdsPerRoom[roomId])
			{
				for (auto& item : instanceIdsPerRoom)
				{
					if (roomId == item.first)
						continue;
					if (item.second.count(instanceIdInMajorRoom))
						item.second.erase(instanceIdInMajorRoom);
				}
			}
			instanceIdsPerRoom[roomId].clear();
		}

	}

	//push to validRooms
	for (unsigned int roomId : validIds)
		validRooms.push_back(rooms[roomId]);

	if (validRooms.size() != 1)
	{
		std::cout << "more than 1 room" << std::endl;
		return false;
	}

	return true;



}

void filter_rooms(TriMeshf& tempTriMesh, const std::vector<bbox3f>& rooms)
{
	std::vector<vec3ui> tri = tempTriMesh.getIndices();
	auto verts = tempTriMesh.getVertices();
	std::vector<vec3ui> newIndices;
	for (int i = 0; i < tempTriMesh.getIndices().size(); i++)
	{
		unsigned int p = tri[i].x;
		unsigned int q = tri[i].y;
		unsigned int r = tri[i].z;
		if ((unsigned int)(verts[p].color[3]) % 1000 == 0)
		{
			bool valid_tri = false;
			for (auto room : rooms)
			{
				if (room.intersects(verts[p].position) && room.intersects(verts[q].position) && room.intersects(verts[r].position))
				{
					valid_tri = true;
					break;
				}
			}
			if (valid_tri)
			{
				newIndices.push_back(vec3ui(p, q, r));
			}

		}
		else
		{
			newIndices.push_back(vec3ui(p, q, r));
		}
	}
	tempTriMesh.m_indices = newIndices;
}

/*bool check_if_outside(TriMeshf mesh, vec3f cameraInWorld)
{
	TriMeshAcceleratorBVHf accel(mesh);
	std::vector<const TriMeshRayAcceleratorf*> accelVec;
	accelVec.push_back(&accel);

	Rayf r(cameraInWorld, vec3f(0,1,0)); //towards sky

	UINT objIdx;
	TriMeshRayAcceleratorf::Intersection intersect;
	bool intersected = TriMeshRayAcceleratorf::getFirstIntersection(r, accelVec, intersect, objIdx);
	return intersected;
}*/


int main(int argc, char* argv[])
{
	std::string scene_id = argv[1];
	
	// GENERAL
	const std::string fileNameDescGlobalApp = "zParameters.txt";
	loadGlobalAppState(fileNameDescGlobalApp);
	const auto& gas = GlobalAppState::get();
	const float voxel_size = gas.s_voxelSize;
	const unsigned int num_improve_steps = gas.s_improveSteps;
	const std::string front3d_data_path = gas.s_front3dPath;
	const std::string input_root_path = gas.s_inputPath;
	const std::string output_root_path = gas.s_outputPath;
	const std::string scene_input_path = input_root_path + "/" + scene_id;
	const std::string scene_output_path = output_root_path + "/" + scene_id;
	const std::string front3d_house_path = front3d_data_path;

	/*if (util::directoryExists(output_root_path) == false)
	{
		util::makeDirectory(output_root_path);
	}

	if (util::directoryExists(scene_output_path) == false) 
	{
		util::makeDirectory(scene_output_path);
	}*/

	// Define frustum
	float depth_min = gas.s_depthMin;
	float depth_max = gas.s_depthMax;
	mat4f intrinsic(277.1281435,      0.,		  159.5,	0.,
					0.,		     277.1281435,	  119.5,	0.,
					0.,			   0.,			1.,		0.,
					0.,			   0.,			0.,		1.);

	mat4f intrinsic_inv = intrinsic.getInverse();
	std::vector<float> image_size = { 320., 240. };
	bbox3f frustum_box = compute_frustum(depth_min, depth_max, intrinsic_inv, image_size);
	vec3f extent = frustum_box.getExtent();
	vec3ui grid_dimensions = math::ceil(extent / voxel_size);
	mat4f world2grid = mat4f::scale(1.0f / voxel_size) * mat4f::translation(-frustum_box.getMin());
	const auto frustum_points = get_frustum_points(depth_min, depth_max, intrinsic_inv, image_size);
	const auto frustum_planes = get_frustum_planes(frustum_points);

	// SCENE
	// Load json
	Front3D::Scene scene;

	std::cout << (front3d_house_path + scene_id + ".json");

	scene.load_from_json(front3d_house_path + scene_id + ".json",
		gas.s_future3d_path,
		gas.s_inputPath,
		gas.s_front3dLabelMapFile);


	// Load 2D instance mapping
	std::string segmentation_meta_path = scene_input_path + "/class_inst_col_map.csv";
	LabelUtil instance_id2object_name;
	instance_id2object_name.init(segmentation_meta_path, "name", "idx");

	std::cout << (gas.s_frameIdsPath + scene_id + ".json\n");

	LabelUtil instance_id2category;
	instance_id2category.init(segmentation_meta_path, "category_id", "idx");

	// FRAME
    std::cout << (gas.s_frameIdsPath + scene_id + ".json\n");

	// read in frame lists from file
	std::ifstream frame_id_path(gas.s_frameIdsPath + scene_id + ".json");
	njson frame_ids_json;
	frame_id_path >> frame_ids_json;
	std::vector<std::string> frame_ids = frame_ids_json;
	std::sort(frame_ids.begin(), frame_ids.end());

	// MAIN PART
	std::vector<std::string> invalid_frames;
	std::unordered_map<std::string, std::unordered_map<std::string, std::unordered_map<std::string, int>>> per_frame_stats;
	std::map<std::string, TriMeshf> room_mesh_cache;

	for (const auto& frame_id : frame_ids) 
	{
		std::cout << scene_id << " - " << frame_id;
		
		// Load pose
		std::string pose_path = scene_input_path + "/campose_" + frame_id + ".npy";
		auto res = cnpy::npy_load(pose_path);
		auto elements = res.data<char>();
		std::stringstream content;
		for (int i = 0; i < res.word_size; ++i) {
			content << elements[i];
		}
		njson j = njson::parse(content.str());
		njson matrix = j[0]["matrix"];
		//std::cout << j.dump(4) << std::endl;
		mat4f pose;

		const int room_index = j[0]["customprop_room_id"];
		const std::string room_name = scene.room_index_mapping[room_index];

		const auto row_0 = matrix[0].get<std::vector<float>>();
		pose(0, 0) = row_0[0];
		pose(0, 1) = row_0[1];
		pose(0, 2) = row_0[2];
		pose(0, 3) = row_0[3];

		// convert from blender to our coord system
		//  [0, -2, 1] ==> [0, 1, 2]
		const auto row_1 = matrix[2].get<std::vector<float>>();
		pose(1, 0) = row_1[0];
		pose(1, 1) = row_1[1];
		pose(1, 2) = row_1[2];
		pose(1, 3) = row_1[3];

		const auto row_2 = matrix[1].get<std::vector<float>>();
		pose(2, 0) = -row_2[0];
		pose(2, 1) = -row_2[1];
		pose(2, 2) = -row_2[2];
		pose(2, 3) = -row_2[3];

		const auto row_3 = matrix[3].get<std::vector<float>>();
		pose(3, 0) = row_3[0];
		pose(3, 1) = row_3[1];
		pose(3, 2) = row_3[2];
		pose(3, 3) = row_3[3];

		mat4f rotation_transform = mat4f::rotationY(180);

		mat4f flip = mat4f::scale(-1.0, 1.0, 1.0);

		pose = pose * rotation_transform * flip;
		mat4f world2camera = pose.getInverse();
		
		
		// Subdivide room mesh, if not in cache
		const auto& room_cached = room_mesh_cache.find(room_name);

		if (room_cached == room_mesh_cache.end()) 
		{
			MeshDataf room_mesh_data = scene.get_room_mesh(room_name);
			room_mesh_data.makeTriMesh();
			TriMeshf room_mesh(room_mesh_data);
			TriMeshf room_mesh_fine = room_mesh.flatLoopSubdivision(10, 0.10);

			room_mesh_cache.emplace(room_name, room_mesh_fine);

			std::cout << " - cached";
		}

		TriMeshf room_mesh(room_mesh_cache[room_name]);
		room_mesh.transform(world2camera);

		if (gas.s_bDebugOut) {
			MeshIOf::saveToFile(scene_output_path + "/mesh_original_" + frame_id + ".ply", room_mesh.computeMeshData());
		}

		// Frustum & room bounding box culling
		const auto& room_vertices = room_mesh.getVertices();
			
		std::vector<vec3ui> indices_culled;
		for (const auto& tri : room_mesh.getIndices())
		{
			const auto& p = room_vertices[tri.x].position;
			const auto& q = room_vertices[tri.y].position;
			const auto& r = room_vertices[tri.z].position;

			// Frustum check
			bool p_within_frustum = is_inside_frustum(frustum_planes, p);
			bool q_within_frustum = is_inside_frustum(frustum_planes, q);
			bool r_within_frustum = is_inside_frustum(frustum_planes, r);

			bool is_within_frustum = p_within_frustum || q_within_frustum || r_within_frustum;

			// at least vertex within frustum
			if (is_within_frustum == true) {
				indices_culled.push_back(vec3ui(tri.x, tri.y, tri.z));
			}
		}
		room_mesh.m_indices = indices_culled;
		std::cout << " - clipped";

		// Voxelize into distance field and perform improvement
		DistanceField3f distance_field;
		make_level_set3(room_mesh, frustum_box.getMin(), grid_dimensions, voxel_size, distance_field);

		for (size_t j = 0; j < distance_field.getNumElements(); j++) {
			distance_field.getData()[j] = std::abs(distance_field.getData()[j]) / voxel_size;
		}
		std::cout << " - voxelized (df)";
			

		distance_field.improveDF(num_improve_steps);
		std::cout << " - improved (df)";

		saveDistanceFieldDense(scene_output_path + "/geometry_" + frame_id + ".npz", distance_field);

		// Voxelize semantics
		Grid3<unsigned int> voxel_grid(grid_dimensions.x, grid_dimensions.y, grid_dimensions.z);

		voxelize(voxel_grid, room_mesh, world2grid, false, false);
		std::cout << " - voxelized (seg)";

		std::unordered_map<std::string, int> frame_instance_stats;
		std::unordered_map<std::string, int> frame_semantic_stats;

		Grid3<unsigned int> segmentation(distance_field.getDimensions());
		segmentation.setValues(0);
		for (const auto& voxel : distance_field) {
			if (voxel.value <= 1.0) {
				bool ok = true;
				unsigned int label = computeLabel(vec3ui(voxel.x, voxel.y, voxel.z), voxel_grid, ok);
				segmentation(voxel.x, voxel.y, voxel.z) = label;

				if (ok == false) {
					continue;
				}

				int instance_label = static_cast<int>(label % 1000);
				if (frame_instance_stats.find(std::to_string(instance_label)) == frame_instance_stats.end()) {
					frame_instance_stats.emplace(std::to_string(instance_label), 1);
				}
				else {
					frame_instance_stats[std::to_string(instance_label)]++;
				}

				int semantic_label = static_cast<int>(label / 1000);
				if (frame_semantic_stats.find(std::to_string(semantic_label)) == frame_semantic_stats.end()) {
					frame_semantic_stats.emplace(std::to_string(semantic_label), 1);
				}
				else {
					frame_semantic_stats[std::to_string(semantic_label)]++;
				}
			}
		}

		const std::unordered_map<std::string, std::unordered_map<std::string, int>> segmentation_stats = { {"instances", frame_instance_stats}, {"semantics", frame_semantic_stats} };

		per_frame_stats.emplace(frame_id, segmentation_stats);
		std::cout << " - improved (seg)";

		saveSemanticsToFile(scene_output_path + "/segmentation_" + frame_id + ".sem", segmentation, true);
		std::cout << "- saved (seg) - done" << std::endl;

	}

	std::cout << "Save meta data" << std::endl;
	njson meta_data{};

	meta_data["mapping"] = scene.instance_name_instance_id_mapping;
	meta_data["instances"] = scene.instance_object_counter;
	meta_data["per_frame_stats"] = per_frame_stats;
	
	std::ofstream meta_output_stream(scene_output_path + "/meta.json");
	meta_output_stream << std::setw(4) << meta_data << std::endl;
}

