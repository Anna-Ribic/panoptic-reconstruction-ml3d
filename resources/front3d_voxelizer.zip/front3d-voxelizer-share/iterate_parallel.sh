#!/bin/bash

# Assuming your method is called using "./frv" and takes the filename without the extension as an argument


# Change the directory path as needed
DIRECTORY_PATH="../output3/"

# Lock file

# Text file to store processed JSON filenames
PROCESSED_FILE="processed_files.txt"

# Function to process a single JSON file
# Function to process a single JSON file
process_json_file() {
    json_file="$1"
    filename=$(basename "$json_file" .json)

    # Acquire a lock for the JSON file
    echo "$LOCK_FILE/$filename"
    if mkdir "json_lock/$filename"; then
        # Lock acquired successfully

        # Check if the JSON file has been processed
        if grep -Fxq "$json_file" "processed_files.txt"; then
            echo "Skipping $json_file as it has already been processed."
        else
            # Process the JSON file
            output_file="outs/output_$filename.txt"
            echo "Processing $json_file..."
            ./frv "$filename"
            
            # Record the processed JSON file in the text file
            echo "$json_file" >> "processed_files.txt"
        fi

        # Release the lock
        rmdir "json_lock/$filename"
    else
        # Failed to acquire lock, another thread is processing the same JSON file
        echo "Skipping $json_file as another thread is processing $filename"
    fi
}

# Export the function so it can be used by parallel
export -f process_json_file

# Run in parallel with 8 threads
find "$DIRECTORY_PATH" -maxdepth 1 -type f -name "*.json" | parallel -j 16 process_json_file
